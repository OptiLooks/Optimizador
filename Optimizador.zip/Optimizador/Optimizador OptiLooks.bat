@echo off
title Optimizaciones OptiLooks

net session >nul 2>&1
if %errorlevel% == 0 (
    goto :start
) else (
    echo Este script necesita permisos de administrador.
    echo.
    echo Si deseas continuar, acepta el mensaje de UAC.
    pause
    :: Intentar ejecutar el script como administrador
    powershell -Command "Start-Process '%0' -Verb runAs"
    exit
)

:start
cls

echo -------------------------------------
echo              Optimizador
echo -------------------------------------
echo 1.- Optimizaciones Recomendadas
echo 2.-Optimizaciones de sistema
echo 3.-Optimizaciones Mas usadas
echo 4.-desactivar Windwos Defender
echo 5.- Salir

set /p op=Opcion: 
if "%op%"=="" goto :start
if "%op%"=="1" goto :or
if "%op%"=="2" goto :ods
if "%op%"=="3" goto :omu
if "%op%"=="4" goto :dwd
if "%op%"=="5" exit

:or
cls
echo Optimizaciones Recomendadas

taskkill /f /im "chrome.exe" > nul 2>&1
taskkill /f /im "discord.exe" > nul 2>&1
taskkill /f /im "steam.exe" > nul 2>&1

del /q /f %temp%\* > nul 2>&1
del /q /f C:\Windows\Temp\* > nul 2>&1

echo Optimizaciones recomendadas aplicadas.
echo Redes de sociales
echo Tiktok:Nada_XD
echo Ig:Lautaro_TX
pause
goto :start

:ods
cls
echo Optimizaciones de Sistema

powercfg -change standby-timeout-ac 0
powercfg -change monitor-timeout-ac 0

start /high "C:\Ruta\al\juego.exe"

echo Optimizaciones de sistema aplicadas.
echo Tiktok:Nada_XD
echo Ig:Lautaro_TX
pause
goto :start

:omu
cls
echo Optimizaciones Más Usadas

reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f  > nul
reg add "HKCU\Control Panel\Desktop" /v "UserPreferencesMask" /t REG_BINARY /d "90 12 03 80" /f > nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications" /v "NoToastApplicationNotification" /t REG_DWORD /d "1" /f > nul

defrag C: /O

echo Optimizaciones más usadas aplicadas.
echo Tiktok:Nada_XD
echo Ig:Lautaro_TX
pause
goto :start

:dwd
cls
echo Desactivando Windows Defender

sc stop WinDefend
sc config WinDefend start=disabled

echo Windows Defender desactivado.
echo Tiktok:Nada_XD
echo Ig:Lautaro_TX
pause
goto :start

:c
cls

echo------------------------------------
echo              CREDITOS
echo------------------------------------
echo Codigo del menu creado por:OptiLooks
echo Codigo de optimizaciones creado por:OptiLooks AI
echo Optimizador creado por:OptiLooks
echo Optilooks Creado por:Nada_XD
goto:start